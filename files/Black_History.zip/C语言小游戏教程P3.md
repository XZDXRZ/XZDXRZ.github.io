---
title: C语言小游戏教程P3
date: 2019-02-10 13:31:20
tags:
	- C语言
	- 教程
	- 小游戏
categories: C语言小游戏教程
---

# 3. 生成僵尸

玩家可以移动了，可是没有僵尸怎行！

下一步，生成僵尸！

为了方便，先定义一个结构体Zombie，代码如下：

<!-- more -->

```c
struct Zombie {
	int id;
	int x,y;
	int dead;
};
```

有僵尸的x坐标，y坐标，还有它死了没（当dead==0时，死；反之，当dead==1时，活），没有变量health，因为我准备秒它，嗯

then，给它一个实例：

```c
Zombie z[5];
```

 接下来，定义一个生成函数，代码如下，在下面我会进行说明：

```c
void m_init(int id)
{
	int tx,ty;//临时变量，记录x，y坐标
	srand((short)time(NULL));//随机重置
	a:tx=rand()%10;//随机取值tx，ty
	ty=rand()%10;
	if (map[tx][ty]==' ')//如果此格是空格
	{
		map[tx][ty]='Z';//此格为僵尸
		z[id].id=id;//更新僵尸信息
		z[id].x=tx;
		z[id].y=ty;
		z[id].dead=0;//它还没死
	}
	else//如果不是
		goto a;//重新取值
}
```

 它只维护了一个参数，就是僵尸的id

其他的在注释里有

现在的完整代码如下：

```c
#include <stdio.h>
#include <time.h>//想要用time()函数，需要这个头文件 
#define MAXN 100
int x=3,y=6;
struct Zombie
{
	int id;
	int x,y;
	int dead;
};
struct Zombie z[5];
char map[MAXN][MAXN]={"##############",
					  "#            #",
					  "#            #",
					  "#     I      #",
					  "#            #",
					  "#            #",
					  "##############"
					 };
void m_init(int id)
{
	int tx,ty;//临时变量，记录x，y坐标
	srand((short)time(NULL));//随机重置
	a:tx=rand()%10;//随机取值tx，ty
	ty=rand()%10;
	if (map[tx][ty]==' ')//如果此格是空格
	{
		map[tx][ty]='Z';//此格为僵尸
		z[id].id=id;//更新僵尸信息
		z[id].x=tx;
		z[id].y=ty;
		z[id].dead=0;//它还没死
	}
	else//如果不是
		goto a;//重新取值
}
void putmap(int lines)
{
	int i;
	for (i=0;i<=lines-1;i++)
	{
		puts(map[i]);
	}
}
void move(char ch)//这里我多了一个参数，为了让程序更有条理性
{
	switch(ch)
	{
		case 'w':
			if (map[x-1][y]==' ')
			{
            	map[x][y]=' ';
            	x--;
            	map[x][y]='I';
        	}
        	break;
		case 'a':
			if (map[x][y-1]==' ')
			{
				map[x][y]=' ';
				y--;
				map[x][y]='I';
			}
			break;
		case 's':
			if (map[x+1][y]==' ')
			{
				map[x][y]=' ';
				x++;
				map[x][y]='I';
			}
			break;
		case 'd':
			if (map[x][y+1]==' ')
			{
				map[x][y]=' ';
				y++;
				map[x][y]='I';
			}
			break;
		default:
			break;
	}
	system("cls");//清屏
	putmap(7);//输出新地图
}
int main()
{
	char ch;
	int i;
	for (i=0;i<=4;i++)
		m_init(i);
	putmap(7);
	while(1)
	{
		ch = getch();
		move(ch);
	}
	return 0;
}
```

Bye~~