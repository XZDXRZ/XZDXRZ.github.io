---
title: C语言小游戏教程P4
date: 2019-02-10 13:31:47
tags:
	- C语言
	- 教程
	- 小游戏
categories: C语言小游戏教程
---

# 4. 玩家攻击

昨天生成完了僵尸，咱们在要打死它们，啊哈哈

~~代码是超级超级超级简单的，我真的不骗你们，瞧好了！~~

<!-- more -->

```c
case ' ':
	//如果附近有僵尸 
	if (map[x-1][y]=='Z') {
    	map[x-1][y]=' ';//那个为空格 
    	is_dead(x,y);//判断是哪只僵尸死了 
    }
    //下面的以此类推 
    if (map[x][y-1]=='Z') {
    	map[x][y-1]=' ';
    	is_dead(x,y);
    }
    if (map[x+1][y]=='Z') {
    	map[x+1][y]=' ';
    	is_dead(x,y);
    }
    if (map[x][y+1]=='Z') {
    	map[x][y+1]=' ';
    	is_dead(x,y);
    }
	break;
```

这些代码放在move()函数里的switch()语句中

is_dead()函数定义如下：

```c
void is_dead(int tx,int ty) {//判断是哪只僵尸死了 
	int i;//定义循环变量 
    for (i=0;i<=4;i++) {//依次判断每只僵尸
        if (z[i].x==tx+1 || z[i].x==tx-1 || z[i].y==ty-1 || z[i].y==ty-1)//判断它们是否在玩家旁边 
            z[i].dead=1;//它挂了。。。 
    }
}
```

~~简单吧~~

完整代码我下节给出，拜拜~~