---
title: C语言小游戏教程P1
date: 2019-02-10 12:30:16
tags:
	- C语言
	- 教程
	- 小游戏
categories: C语言小游戏教程
---

<!--
1. [开始](/zombies1/)
2. [我得动呀！](/zombies2/)
3. [生成僵尸](/zombies3/)
4. [玩家攻击](/zombies4/)
5. [僵尸移动](zombies5/)
6. [僵尸打人](/zombies6/)
7. [界面美化](/zombies7/)
8. [完结撒花！](/zombies8/)
-->

# 1. 开始

Hello everyone！我是仙人掌，~~我不扎人~~，嗯。

我的第一篇博客就是这个，如果你不会C语言高级编程，就pass掉吧，拜拜！

##### 诶，怎么就拜拜了？！

<!-- more -->

好吧，开个玩笑，这篇文章只要你会一点点C语言就行。

OK，咱们正式开始：

首先，得把目标确定下来，就一个回合制的僵尸游戏吧，这个项目我已经写过，就在[Zombies on GitHub](https://github.com/XZDXRZ/Zombies)，嗯。

接着，在Dev-C++里创建一个项目，命名为“Zombies”

![创建项目](/images/zombies/1.png)

![创建项目](/images/zombies/2.png)

![创建项目](/images/zombies/3.png)

创建完项目后，结束我们第一课，嗯！

#### 诶诶诶怎么就结束了？！回来回来！嘿！