---
title: C语言小游戏教程P8
date: 2019-02-10 13:33:40
tags:
	- C语言
	- 教程
	- 小游戏
categories: C语言小游戏教程
---

# 8. 完结撒花！

### C语言小游戏教程 - 完结篇

完整代码：

<!-- more -->

```c
#include <stdio.h>
#include <time.h>//想要用time()函数，需要这个头文件
#include <windows.h>//Sleep()函数在这里面 
#define MAXN 100
int x=3,y=6;
int health=10;//玩家的生命值
struct Zombie
{
	int id;
	int x,y;
	int dead;
};
struct Zombie z[5];
char _map[MAXN][MAXN]={"##############",
					  "#            #",
					  "#            #",
					  "#     I      #",
					  "#            #",
					  "#            #",
					  "##############"
					 };
void is_dead(int tx,int ty)//判断是哪只僵尸死了 
{
	int i;//定义循环变量 
    for (i=0;i<=4;i++)//依次判断每只僵尸
	{
        if (z[i].x==tx+1 || z[i].x==tx-1 || z[i].y==ty-1 || z[i].y==ty-1)//判断它们是否在玩家旁边 
            z[i].dead=1;//它挂了。。。 
    }
}
int have_zombie()
{
	int i,j;
	for (i=0;i<MAXN;i++)//枚举每一个点 
		for (j=0;j<MAXN;j++)
			if (_map[i][j]=='Z')//如果有僵尸 
				return 1;//因为C语言没有boolean，所以用整型代替 
	return 0;
}
void m_init(int id)
{
	int tx,ty;//临时变量，记录x，y坐标
	srand((short)time(NULL));//随机重置
	a:tx=rand()%10;//随机取值tx，ty
	ty=rand()%10;
	if (_map[tx][ty]==' ')//如果此格是空格
	{
		_map[tx][ty]='Z';//此格为僵尸
		z[id].id=id;//更新僵尸信息
		z[id].x=tx;
		z[id].y=ty;
		z[id].dead=0;//它还没死
	}
	else//如果不是
		goto a;//重新取值
}
void m_attark(int id)
{
	if (_map[z[id].x+1][z[id].y]=='I')//判断周围有没有玩家 
		health--;//有则攻击 
	if (_map[z[id].x-1][z[id].y]=='I')
		health--;
	if (_map[z[id].x][z[id].y+1]=='I')
		health--;
	if (_map[z[id].x][z[id].y-1]=='I')
		health--;
}
void m_move(int id)//参数id就是僵尸的编号 
{
	int direction;//方向 
	srand((short)time(NULL));
	direction=rand()%4;//随机方向 
	switch(direction)//判断 
	{
		case 1://向上 
			if (_map[z[id].x-1][z[id].y]==' ')//如果下一格是空格 
			{
				_map[z[id].x][z[id].y]=' ';
				z[id].x--;
				_map[z[id].x][z[id].y]='Z';
			}
			break; 
		case 2://向下 
			if (_map[z[id].x+1][z[id].y]==' ')//接下来以此类推 
			{
				_map[z[id].x][z[id].y]=' ';
				z[id].x++;
				_map[z[id].x][z[id].y]='Z';
			}
			break;
		case 3://向左
			if (_map[z[id].x][z[id].y-1]==' ')
			{
				_map[z[id].x][z[id].y]=' ';
				z[id].y--;
				_map[z[id].x][z[id].y]='Z';
			}
			break;
		case 4://向右
			if (_map[z[id].x][z[id].y+1]==' ')
			{
				_map[z[id].x][z[id].y]=' ';
				z[id].y++;
				_map[z[id].x][z[id].y]='Z';
			}
			break;
		default:
			break;
	}
	m_attark(id);
}
void putmap(int lines)
{
	int i;
	for (i=0;i<=lines-1;i++)
	{
		puts(_map[i]);
	}
}
void move(char ch)//这里我多了一个参数，为了让程序更有条理性
{
	switch(ch)
	{
		case 'w':
			if (_map[x-1][y]==' ')
			{
            	_map[x][y]=' ';
            	x--;
            	_map[x][y]='I';
        	}
        	break;
		case 'a':
			if (_map[x][y-1]==' ')
			{
				_map[x][y]=' ';
				y--;
				_map[x][y]='I';
			}
			break;
		case 's':
			if (_map[x+1][y]==' ')
			{
				_map[x][y]=' ';
				x++;
				_map[x][y]='I';
			}
			break;
		case 'd':
			if (_map[x][y+1]==' ')
			{
				_map[x][y]=' ';
				y++;
				_map[x][y]='I';
			}
			break;
		case ' ':
			//如果附近有僵尸 
			if (_map[x-1][y]=='Z') {
    			_map[x-1][y]=' ';//那个为空格 
    			is_dead(x,y);//判断是哪只僵尸死了 
    		}
    		//下面的以此类推 
    		if (_map[x][y-1]=='Z') {
    			_map[x][y-1]=' ';
    			is_dead(x,y);
    		}
    		if (_map[x+1][y]=='Z') {
    			_map[x+1][y]=' ';
    			is_dead(x,y);
    		}
    		if (_map[x][y+1]=='Z') {
    			_map[x][y+1]=' ';
    			is_dead(x,y);
    		}
			break;
		default:
			break;
	}
	system("cls");//清屏
	putmap(7);//输出新地图
}
int main()
{
	char ch;
	int i;
	for (i=0;i<=4;i++)
		m_init(i);
	putmap(7);
	printf("你的生命值：%d\n",health);//开始也要输出一下初始状态 
	while(1)
	{
		ch = getch();
		move(ch);
		for (i=0;i<=4;i++)//枚举每一个僵尸
			if (_map[z[i].x][z[i].y]=='Z'/*判断这一格是不是僵尸，建议加上，否则会出bug*/&&!z[i].dead/*并且它没死*/)//加上这层判断，可以让死掉的僵尸不会再动 
				m_move(i);//一个一个动
		printf("你的生命值：%d\n",health);//在用户界面输出血量 
		if (health<=0)//如果生命值小于等于0 
		{
			system("color c4");//吓吓
			printf("你失败了！\n");
			Sleep(2000);//暂停2秒 
			return 0;//结束程序
		}
		if (!have_zombie())
		{
			printf("你胜利了！\n");
			Sleep(2000);
			return 0;
		}
	}
	return 0;
}
```

这坑也算填完了

完结撒花！

FLOWER!

Bye~~

下期再见