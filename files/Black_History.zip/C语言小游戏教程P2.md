---
title: C语言小游戏教程P2
date: 2019-02-10 13:29:58
tags:
	- C语言
	- 教程
	- 小游戏
categories: C语言小游戏教程
---

# 2. 我得动呀！

昨天创建完了项目，我就跑了，嗯。

首先，我们把Dev-C++自动生成的代码删去，写上：

<!-- more -->

```c
#include <stdio.h>
int main()
{
	
	return 0;
}
```

这是C语言必有的main函数，不用给他任何参数。

然后，我们声明一张地图，简单点，把它放在全局变量，就：

```c
#define MAXN 100
char map[MAXN][MAXN]={"##############",
					"#            #",
					"#            #",
					"#     I      #",
					"#            #",
					"#            #",
					"##############"
				    };
```

这里我用#define预处理名声明了一个常量MAXN，便于以后修改。

定义完地图后，得把它输出到屏幕上，很简单：

```c
void putmap(int lines)
{
	int i;
	for (i=0;i<=lines-1;i++)
	{
		puts(map[i]);
	}
}
```

在main函数调用这个函数：

```c
putmap(7);
```

运行结果如下：

![运行结果](/images/zombies/4.png)

这里我定义了一个函数，用于输出地图，它只需维护一个参数，就是地图的行数lines。

接下来，让这个角色动起来，实现代码如下，我会在下面进行解释：

```c
void move()
{
	char ch;
	ch=getch();
	switch(ch)
	{
		case 'w':
			if (map[x-1][y]==' ')
			{
            	map[x][y]=' ';
            	x--;
            	map[x][y]='I';
        	}
        	break;
		case 'a':
			if (map[x][y-1]==' ')
			{
				map[x][y]=' ';
				y--;
				map[x][y]='I';
			}
			break;
		case 's':
			if (map[x+1][y]==' ')
			{
				map[x][y]=' ';
				x++;
				map[x][y]='I';
			}
			break;
		case 'd':
			if (map[x][y+1]==' ')
			{
				map[x][y]=' ';
				y++;
				map[x][y]='I';
			}
			break;
		default:
			break;
	}
	system("cls");//清屏
	putmap(7);//输出新地图
}
```

咱们就解释`case 'w':`吧，其他的以此类推，

先是一个`if (map[x-1][y]==' ')`判断下一步是不是空格，没学过二维坐标系的同学不要把这个和二维坐标系搞混了，这里的`x`和`y`正好和二维坐标系反了，所以别搞混了。

- `map[x][y]=' ';` 让这格为空格；
- `x--;` 让角色的x坐标减1；
- `map[x][y]='I';` 减完后让这格为角色字母；

其他的以此类推。
完整代码如下：

```c
#include <stdio.h>
#define MAXN 100
int x=3,y=6;
char map[MAXN][MAXN]={"##############",
					  "#            #",
					  "#            #",
					  "#     I      #",
					  "#            #",
					  "#            #",
					  "##############"
					 };
void putmap(int lines)
{
	int i;
	for (i=0;i<=lines-1;i++)
	{
		puts(map[i]);
	}
}
void move()
{
	char ch;
	ch=getch();
	switch(ch)
	{
		case 'w':
			if (map[x-1][y]==' ')
			{
            	map[x][y]=' ';
            	x--;
            	map[x][y]='I';
        	}
        	break;
		case 'a':
			if (map[x][y-1]==' ')
			{
				map[x][y]=' ';
				y--;
				map[x][y]='I';
			}
			break;
		case 's':
			if (map[x+1][y]==' ')
			{
				map[x][y]=' ';
				x++;
				map[x][y]='I';
			}
			break;
		case 'd':
			if (map[x][y+1]==' ')
			{
				map[x][y]=' ';
				y++;
				map[x][y]='I';
			}
			break;
		default:
			break;
	}
	system("cls");//清屏
	putmap(7);//输出新地图
}
int main()
{
	putmap(7);
	while(1)
	{
		move();
	}
	return 0;
}
```

其中`while(1)`起到的作用就是死循环。

今天就讲到这，拜拜！